import type { ImagePlaceholder } from './placeholder-images';
import { PlaceHolderImages } from './placeholder-images';

export type NutritionInfo = {
  servingSize: string;
  calories: number;
  protein: number;
  fat: number;
  carbohydrates: number;
  sodium: number;
};

export type Dish = {
  id: string;
  name: string;
  description: string;
  category: string;
  isBestSeller: boolean;
  image: ImagePlaceholder;
  ingredients: string[];
  cuisine: string;
  price: {
    original: number;
    plantBased: number;
  };
  nutrition: {
    original: NutritionInfo;
    plantBasedInitial: NutritionInfo;
    plantBasedOptimized: NutritionInfo;
  };
  impact: number;
};

const findImage = (id: string): ImagePlaceholder => {
  const image = PlaceHolderImages.find((img) => img.id === id);
  if (!image) {
    // Fallback to a default image if not found
    return PlaceHolderImages[0];
  }
  return image;
};

export const menuData: Dish[] = [
  {
    id: 'classic-beef-burger',
    name: 'Classic Beef Burger',
    description: 'Juicy beef patty with lettuce, tomato, and our signature sauce',
    category: 'Mains',
    isBestSeller: false,
    image: findImage('4'),
    ingredients: ['Beef patty', 'lettuce', 'tomato', 'signature sauce', 'bun'],
    cuisine: 'American',
    price: { original: 14.99, plantBased: 15.99 },
    nutrition: {
      original: { servingSize: '1 burger', calories: 650, protein: 35, fat: 38, carbohydrates: 45, sodium: 1200 },
      plantBasedInitial: { servingSize: '1 burger', calories: 550, protein: 30, fat: 30, carbohydrates: 50, sodium: 1100 },
      plantBasedOptimized: { servingSize: '1 burger', calories: 600, protein: 35, fat: 32, carbohydrates: 48, sodium: 1100 },
    },
    impact: 150,
  },
  {
    id: 'fish-and-chips',
    name: 'Fish & Chips',
    description: 'Beer-battered cod with crispy fries and tartar sauce',
    category: 'Mains',
    isBestSeller: false,
    image: findImage('1'),
    ingredients: ['Cod', 'flour', 'potatoes', 'tartar sauce'],
    cuisine: 'British',
    price: { original: 16.99, plantBased: 17.99 },
    nutrition: {
      original: { servingSize: '1 plate', calories: 820, protein: 28, fat: 45, carbohydrates: 75, sodium: 1400 },
      plantBasedInitial: { servingSize: '1 plate', calories: 720, protein: 20, fat: 38, carbohydrates: 80, sodium: 1300 },
      plantBasedOptimized: { servingSize: '1 plate', calories: 770, protein: 28, fat: 40, carbohydrates: 78, sodium: 1300 },
    },
    impact: 110,
  },
  {
    id: 'grilled-salmon',
    name: 'Grilled Salmon',
    description: 'Atlantic salmon with lemon butter sauce and seasonal vegetables',
    category: 'Mains',
    isBestSeller: true,
    image: findImage('12'),
    ingredients: ['Atlantic salmon', 'lemon butter sauce', 'seasonal vegetables'],
    cuisine: 'American',
    price: { original: 22.99, plantBased: 23.99 },
    nutrition: {
      original: { servingSize: '1 plate', calories: 520, protein: 42, fat: 34, carbohydrates: 10, sodium: 600 },
      plantBasedInitial: { servingSize: '1 plate', calories: 480, protein: 30, fat: 30, carbohydrates: 15, sodium: 550 },
      plantBasedOptimized: { servingSize: '1 plate', calories: 500, protein: 42, fat: 31, carbohydrates: 12, sodium: 550 },
    },
    impact: 80,
  },
  {
    id: 'chicken-caesar-salad',
    name: 'Chicken Caesar Salad',
    description: 'Grilled chicken breast on crisp romaine with parmesan and croutons',
    category: 'Salads',
    isBestSeller: false,
    image: findImage('5'),
    ingredients: ['Grilled chicken breast', 'romaine', 'parmesan', 'croutons', 'caesar dressing'],
    cuisine: 'American',
    price: { original: 12.99, plantBased: 13.99 },
    nutrition: {
      original: { servingSize: '1 bowl', calories: 480, protein: 32, fat: 32, carbohydrates: 15, sodium: 900 },
      plantBasedInitial: { servingSize: '1 bowl', calories: 400, protein: 20, fat: 28, carbohydrates: 18, sodium: 800 },
      plantBasedOptimized: { servingSize: '1 bowl', calories: 440, protein: 32, fat: 30, carbohydrates: 16, sodium: 800 },
    },
    impact: 90,
  },
  {
    id: 'eggs-benedict',
    name: 'Eggs Benedict',
    description: 'Poached eggs on English muffin with Canadian bacon and hollandaise',
    category: 'Breakfast',
    isBestSeller: false,
    image: findImage('11'),
    ingredients: ['Poached eggs', 'English muffin', 'Canadian bacon', 'hollandaise sauce'],
    cuisine: 'American',
    price: { original: 13.99, plantBased: 14.99 },
    nutrition: {
      original: { servingSize: '1 plate', calories: 580, protein: 24, fat: 42, carbohydrates: 25, sodium: 1300 },
      plantBasedInitial: { servingSize: '1 plate', calories: 500, protein: 18, fat: 35, carbohydrates: 28, sodium: 1200 },
      plantBasedOptimized: { servingSize: '1 plate', calories: 540, protein: 24, fat: 38, carbohydrates: 26, sodium: 1200 },
    },
    impact: 60,
  },
  {
    id: 'creamy-tomato-soup',
    name: 'Creamy Tomato Soup',
    description: 'Rich tomato soup with heavy cream and fresh basil',
    category: 'Soups',
    isBestSeller: false,
    image: findImage('6'),
    ingredients: ['Tomatoes', 'heavy cream', 'fresh basil', 'vegetable broth'],
    cuisine: 'International',
    price: { original: 7.99, plantBased: 8.49 },
    nutrition: {
      original: { servingSize: '1 bowl', calories: 320, protein: 6, fat: 22, carbohydrates: 25, sodium: 700 },
      plantBasedInitial: { servingSize: '1 bowl', calories: 280, protein: 4, fat: 18, carbohydrates: 28, sodium: 650 },
      plantBasedOptimized: { servingSize: '1 bowl', calories: 300, protein: 6, fat: 20, carbohydrates: 26, sodium: 650 },
    },
    impact: 30,
  },
];
