'use server';

/**
 * @fileOverview Generates a short video reel for a plant-based dish.
 *
 * - generateVideoReel - A function that handles the video reel generation process.
 * - GenerateVideoReelInput - The input type for the generateVideoReel function.
 * - GenerateVideoReelOutput - The return type for the generateVideoReel function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { MediaPart } from 'genkit';

const GenerateVideoReelInputSchema = z.object({
  dishName: z.string().describe('The name of the plant-based dish.'),
});
export type GenerateVideoReelInput = z.infer<typeof GenerateVideoReelInputSchema>;

const GenerateVideoReelOutputSchema = z.object({
  videoUrl: z.string().describe('The generated video reel as a data URI.').optional(),
  error: z.string().describe('An error message if video generation failed.').optional(),
});
export type GenerateVideoReelOutput = z.infer<typeof GenerateVideoReelOutputSchema>;

export async function generateVideoReel(
  input: GenerateVideoReelInput
): Promise<GenerateVideoReelOutput> {
  if (!process.env.GEMINI_API_KEY && !process.env.GOOGLE_API_KEY) {
    throw new Error("API Key is missing. Please set GEMINI_API_KEY in your environment secrets.");
  }
  return generateVideoReelFlow(input);
}


const generateVideoReelFlow = ai.defineFlow(
  {
    name: 'generateVideoReelFlow',
    inputSchema: GenerateVideoReelInputSchema,
    outputSchema: GenerateVideoReelOutputSchema,
  },
  async ({ dishName }) => {
    try {
        let { operation } = await ai.generate({
            model: 'googleai/veo-2.0-generate-001',
            prompt: `Create a short, vibrant, and appetizing 5-second video reel for a plant-based dish called "${dishName}". The video should be visually appealing and suitable for social media marketing, especially Instagram Reels. Focus on close-ups of the dish, showing its textures and fresh ingredients. The style should be modern and energetic.`,
            config: {
              durationSeconds: 5,
              aspectRatio: '9:16', // Portrait for reels
            },
          });

        if (!operation) {
            return { error: 'Expected the model to return an operation' };
        }

        // Poll for completion
        while (!operation.done) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait 5 seconds
            operation = await ai.checkOperation(operation);
        }

        if (operation.error) {
            return { error: `Video generation failed: ${operation.error.message}` };
        }

        const videoPart = operation.output?.message?.content.find((p) => !!p.media);
        if (!videoPart || !videoPart.media?.url) {
            return { error: 'Failed to find the generated video in the model response.' };
        }

        const videoUrl = `${videoPart.media.url}&key=${process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY}`;
        
        const videoResponse = await fetch(videoUrl);
        if (!videoResponse.ok) {
            return { error: `Failed to download video: ${videoResponse.statusText}` };
        }
        
        const videoBuffer = await videoResponse.arrayBuffer();
        const videoBase64 = Buffer.from(videoBuffer).toString('base64');
        const videoDataUri = `data:${videoPart.media.contentType || 'video/mp4'};base64,${videoBase64}`;

        return { videoUrl: videoDataUri };
    } catch (e: any) {
        if (e.message && e.message.includes('billing enabled')) {
            return { error: 'Video generation requires a Google Cloud project with billing enabled. To use this model, please ensure your account has active GCP billing.' };
        }
        if (e.message && e.message.includes('quota')) {
            return { error: "You've exceeded the API quota for video generation. Please check your Google Cloud plan and billing details, or try again later." };
        }
        if (e.message && e.message.includes('leaked')) {
            return { error: "Your API key has been compromised and cannot be used. Please generate a new key and update your .env file." };
        }
        return { error: e.message || 'An unknown error occurred during video generation.' };
    }
  }
);
