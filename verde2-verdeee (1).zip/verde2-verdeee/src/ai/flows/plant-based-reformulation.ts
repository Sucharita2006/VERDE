'use server';

/**
 * @fileOverview Analyzes dishes and suggests plant-based alternatives, providing metrics for taste and texture similarity.
 *
 * - plantBasedReformulation - A function that handles the plant-based reformulation process.
 * - PlantBasedReformulationInput - The input type for the plantBasedReformulation function.
 * - PlantBasedReformulationOutput - The return type for the plantBasedReformulation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PlantBasedReformulationInputSchema = z.object({
  dishName: z.string().describe('The name of the dish to reformulate.'),
  ingredients: z.string().describe('A comma-separated list of ingredients in the original dish.'),
  cuisineType: z.string().describe('The cuisine type of the dish.'),
});
export type PlantBasedReformulationInput = z.infer<typeof PlantBasedReformulationInputSchema>;

const PlantBasedReformulationOutputSchema = z.object({
  plantBasedIngredients: z.string().describe('A comma-separated list of plant-based ingredients that can replace the original ingredients.'),
  tasteSimilarity: z.number().describe('A score between 0 and 100 representing the similarity in taste between the original and plant-based dish.'),
  textureSimilarity: z.number().describe('A score between 0 and 100 representing the similarity in texture between the original and plant-based dish.'),
  customerNoticeableDifference: z.string().describe('A description of how noticeable the difference will be to customers (LOW, MEDIUM, HIGH).'),
  ingredientSwapExplanation: z.string().describe('A plain language explanation of the ingredient swaps.'),
});
export type PlantBasedReformulationOutput = z.infer<typeof PlantBasedReformulationOutputSchema>;

export async function plantBasedReformulation(input: PlantBasedReformulationInput): Promise<PlantBasedReformulationOutput> {
  if (!process.env.GEMINI_API_KEY && !process.env.GOOGLE_API_KEY) {
    throw new Error("API Key is missing. Please set GEMINI_API_KEY in your environment secrets.");
  }
  return plantBasedReformulationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'plantBasedReformulationPrompt',
  input: {schema: PlantBasedReformulationInputSchema},
  output: {schema: PlantBasedReformulationOutputSchema},
  prompt: `You are an expert chef specializing in plant-based cuisine. Your goal is to reformulate existing dishes into plant-based alternatives while maintaining similar taste and texture profiles.

  Dish Name: {{{dishName}}}
  Ingredients: {{{ingredients}}}
  Cuisine Type: {{{cuisineType}}}

  Provide a list of plant-based ingredients that can replace the original ingredients. Also, provide a taste similarity score, texture similarity score, a description of how noticeable the difference will be to customers, and an ingredient swap explanation. Adhere to the output schema descriptions provided. Return the response in JSON format.`,
});

const plantBasedReformulationFlow = ai.defineFlow(
  {
    name: 'plantBasedReformulationFlow',
    inputSchema: PlantBasedReformulationInputSchema,
    outputSchema: PlantBasedReformulationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
