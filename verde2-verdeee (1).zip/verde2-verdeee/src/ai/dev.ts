import { config } from 'dotenv';
config();

import '@/ai/flows/plant-based-reformulation.ts';
import '@/ai/flows/generate-marketing-content.ts';
import '@/ai/flows/generate-video-reel.ts';
