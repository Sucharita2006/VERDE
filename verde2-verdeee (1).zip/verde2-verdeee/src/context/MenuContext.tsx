'use client';

import { createContext, useContext, useState, ReactNode } from 'react';
import { menuData, type Dish } from '@/lib/data';
import { PlaceHolderImages, type ImagePlaceholder } from '@/lib/placeholder-images';

type MenuContextType = {
  menuItems: Dish[];
  addMenuItem: (item: Omit<Dish, 'id' | 'image' | 'price' | 'nutrition' | 'impact' | 'isBestSeller'> & { description: string }) => void;
};

const MenuContext = createContext<MenuContextType | undefined>(undefined);

export function MenuProvider({ children }: { children: ReactNode }) {
  const [menuItems, setMenuItems] = useState<Dish[]>(menuData);

  const addMenuItem = (item: Omit<Dish, 'id' | 'image' | 'price' | 'nutrition' | 'impact' | 'isBestSeller'> & { description: string }) => {
    const newId = item.name.toLowerCase().replace(/\s+/g, '-');
    
    const keywords = (item.name + " " + item.category).toLowerCase().split(" ").filter(k => k.length > 2);
    const usedImageUrls = new Set(menuItems.map(d => d.image.imageUrl));
    const unusedImages = PlaceHolderImages.filter(p => !usedImageUrls.has(p.imageUrl));

    let bestMatch: { image: ImagePlaceholder, score: number } | undefined;

    if (unusedImages.length > 0) {
      for (const image of unusedImages) {
        const hintWords = image.imageHint.split(' ');
        const score = hintWords.reduce((acc, hintWord) => {
          if (keywords.some(k => k.includes(hintWord) || hintWord.includes(k))) {
            return acc + 1;
          }
          return acc;
        }, 0);

        if (score > 0 && (!bestMatch || score > bestMatch.score)) {
          bestMatch = { image, score };
        }
      }
    }

    let selectedImage: ImagePlaceholder | undefined = bestMatch?.image;

    if (!selectedImage) {
      if (unusedImages.length > 0) {
        // If no keyword match, pick a deterministic unused image
        selectedImage = unusedImages[item.name.length % unusedImages.length];
      } else {
        // If all images are used, pick a deterministic one from all images
        selectedImage = PlaceHolderImages[item.name.length % PlaceHolderImages.length];
      }
    }

    const originalPrice = (item.name.length % 10) + 10;
    const plantBasedPrice = originalPrice + (item.name.length % 3) + 0.99;

    const newItem: Dish = {
      ...item,
      id: newId,
      image: selectedImage!,
      isBestSeller: false,
      impact: (item.name.length * 7) % 100 + 20, // Deterministic impact
      price: {
        original: parseFloat(originalPrice.toFixed(2)),
        plantBased: parseFloat(plantBasedPrice.toFixed(2)),
      },
      nutrition: { // Mock nutrition data
        original: { servingSize: '200g', calories: 500, protein: 20, fat: 25, carbohydrates: 40, sodium: 900 },
        plantBasedInitial: { servingSize: '200g', calories: 450, protein: 15, fat: 20, carbohydrates: 45, sodium: 800 },
        plantBasedOptimized: { servingSize: '200g', calories: 470, protein: 20, fat: 22, carbohydrates: 42, sodium: 800 },
      },
    };
    setMenuItems(prevItems => [newItem, ...prevItems]);
  };

  return (
    <MenuContext.Provider value={{ menuItems, addMenuItem }}>
      {children}
    </MenuContext.Provider>
  );
}

export function useMenu() {
  const context = useContext(MenuContext);
  if (context === undefined) {
    throw new Error('useMenu must be used within a MenuProvider');
  }
  return context;
}
