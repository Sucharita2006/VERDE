import { cn } from "@/lib/utils";

export function Logo({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      className={cn(className)}
      {...props}
    >
      {/* Rounded green background */}
      <rect
        x="1"
        y="1"
        width="22"
        height="22"
        rx="6"
        fill="#2F5D46"
      />

      {/* Leaf outline */}
      <path
        d="M16.8 7.5c-4.6.2-7.7 2.6-9.1 6.3-.8 2.2.3 4.6 2.7 5.1 2.4.5 4.9-1.1 6.1-3.5.9-1.8 1.1-4.1.3-7.9Z"
        stroke="white"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Leaf vein */}
      <path
        d="M8.5 14.5c2-1.2 4.4-2.4 7-3"
        stroke="white"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}
