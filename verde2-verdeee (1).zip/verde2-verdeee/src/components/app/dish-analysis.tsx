'use client';

import { useState, useEffect, useTransition } from 'react';
import {
  plantBasedReformulation,
  type PlantBasedReformulationOutput,
} from '@/ai/flows/plant-based-reformulation';
import {
  generateMarketingContent,
  type GenerateMarketingContentOutput,
} from '@/ai/flows/generate-marketing-content';
import {
  generateVideoReel,
} from '@/ai/flows/generate-video-reel';
import type { Dish, NutritionInfo } from '@/lib/data';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { AlertTriangle, Bot, Loader2, Sparkles, ExternalLink } from 'lucide-react';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { NutritionLabelDialog } from './nutrition-label-dialog';
import { useToast } from '@/hooks/use-toast';

export function DishAnalysis({ dish }: { dish: Dish }) {
  const { toast } = useToast();
  const [isReformulating, startReformulation] = useTransition();
  const [reformulation, setReformulation] =
    useState<PlantBasedReformulationOutput | null>(null);

  const [isOptimizing, setIsOptimizing] = useState(false);
  const [showOptimizedNutrition, setShowOptimizedNutrition] = useState(false);
  const [plantBasedNutrition, setPlantBasedNutrition] = useState<NutritionInfo | null>(dish.nutrition.plantBasedInitial);

  const [isGeneratingMarketing, startMarketingGeneration] = useTransition();
  const [marketingContent, setMarketingContent] =
    useState<GenerateMarketingContentOutput | null>(null);

  const [isGeneratingReel, startReelGeneration] = useTransition();
  const [videoReelUrl, setVideoReelUrl] = useState<string | null>(null);


  useEffect(() => {
    startReformulation(async () => {
      try {
        const result = await plantBasedReformulation({
          dishName: dish.name,
          ingredients: dish.ingredients.join(', '),
          cuisineType: dish.cuisine,
        });
        setReformulation(result);
      } catch (error: any) {
        console.error('Reformulation failed:', error);
        let description = error.message || 'Could not generate plant-based alternative.';
        if (error.message && error.message.includes('leaked')) {
          description = "Your API key has been compromised and cannot be used. Please generate a new key and update your .env file.";
        } else if (error.message && error.message.includes('quota')) {
          description = "You've exceeded the free API quota. Please check your Google Cloud billing details or try again later.";
        }
        toast({
          variant: 'destructive',
          title: 'Reformulation Failed',
          description: description,
        });
      }
    });
  }, [dish, toast]);

  useEffect(() => {
     if (reformulation && !showOptimizedNutrition) {
      const proteinDifference = dish.nutrition.original.protein - dish.nutrition.plantBasedInitial.protein;
      if (proteinDifference > 2) { // Threshold for noticeable difference
        setIsOptimizing(true);
        const timer = setTimeout(() => {
          setPlantBasedNutrition(dish.nutrition.plantBasedOptimized);
          setShowOptimizedNutrition(true);
          setIsOptimizing(false);
        }, 3000);
        return () => clearTimeout(timer);
      } else {
        setPlantBasedNutrition(dish.nutrition.plantBasedOptimized);
        setShowOptimizedNutrition(true);
      }
    }
  }, [reformulation, dish.nutrition, showOptimizedNutrition]);

  const handleGenerateMarketing = () => {
    startMarketingGeneration(async () => {
       try {
        const result = await generateMarketingContent({ dishName: `Plant-Based ${dish.name}` });
        setMarketingContent(result);
        setVideoReelUrl(null);
      } catch (error: any) {
        console.error('Marketing content generation failed:', error);
        let description = error.message || 'Could not generate marketing content.';
        if (error.message && error.message.includes('leaked')) {
          description = "Your API key has been compromised and cannot be used. Please generate a new key and update your .env file.";
        } else if (error.message && error.message.includes('quota')) {
            description = "You've exceeded the free API quota. Please check your Google Cloud billing details or try again later.";
        }
        toast({
          variant: 'destructive',
          title: 'Marketing Failed',
          description,
        });
      }
    });
  };

  const handleGenerateReel = () => {
    startReelGeneration(async () => {
      setVideoReelUrl(null);
      const result = await generateVideoReel({ dishName: `Plant-Based ${dish.name}` });
      
      if (result.error) {
        console.error('Video reel generation failed:', result.error);
        toast({
          variant: 'destructive',
          title: 'Reel Generation Failed',
          description: result.error,
        });
      } else if (result.videoUrl) {
        setVideoReelUrl(result.videoUrl);
      }
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="text-primary" />
            🌱 Plant-Based Alternative Generated
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isReformulating ? (
            <div className="space-y-4">
              <Skeleton className="h-8 w-1/2" />
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-12 w-full" />
            </div>
          ) : reformulation ? (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <h3 className="font-semibold">Taste Similarity</h3>
                  <div className="flex items-center gap-2">
                    <Progress
                      value={reformulation.tasteSimilarity}
                    />
                    <span className="font-bold">
                      {reformulation.tasteSimilarity}%
                    </span>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold">Texture Similarity</h3>
                  <div className="flex items-center gap-2">
                    <Progress
                      value={reformulation.textureSimilarity}
                    />
                    <span className="font-bold">
                      {reformulation.textureSimilarity}%
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-sm">
                <span className="font-semibold">
                  Customer-noticeable difference:
                </span>{' '}
                <Badge
                  variant={
                    reformulation.customerNoticeableDifference.toUpperCase() ===
                    'LOW'
                      ? 'default'
                      : 'secondary'
                  }
                >
                  {reformulation.customerNoticeableDifference}
                </Badge>
              </p>
              <div>
                <h3 className="font-semibold">Ingredient Swap Explanation</h3>
                <p className="text-sm text-muted-foreground">
                  {reformulation.ingredientSwapExplanation}
                </p>
              </div>
            </div>
          ) : (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                Failed to generate a plant-based alternative. This may be due to API quota limits. Please check your billing details or try again later.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>📊 Nutrition Comparison</CardTitle>
          <CardDescription>Side-by-side view of nutritional information.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isOptimizing && (
             <Alert>
              <Loader2 className="h-4 w-4 animate-spin" />
              <AlertTitle>Protein difference detected!</AlertTitle>
              <AlertDescription>
                Optimizing formulation to better match the original nutrition profile...
              </AlertDescription>
            </Alert>
          )}
          {showOptimizedNutrition && !isOptimizing && (
            <Alert>
               <Sparkles className="h-4 w-4" />
              <AlertTitle>✅ Formulation Optimized</AlertTitle>
              <AlertDescription>
                The plant-based recipe has been updated using pea protein to match the original protein content.
              </AlertDescription>
            </Alert>
          )}

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nutrient</TableHead>
                  <TableHead className="text-right">Original</TableHead>
                  <TableHead className="text-right">Plant-Based</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {!plantBasedNutrition ? (
                  Array.from({length: 4}).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 ml-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : (
                  <>
                    <TableRow>
                      <TableCell>Calories (kcal)</TableCell>
                      <TableCell className="text-right">{dish.nutrition.original.calories}</TableCell>
                      <TableCell className="text-right">{plantBasedNutrition.calories}</TableCell>
                    </TableRow>
                     <TableRow>
                      <TableCell>Protein (g)</TableCell>
                      <TableCell className="text-right">{dish.nutrition.original.protein}</TableCell>
                      <TableCell className="text-right font-bold text-primary">{plantBasedNutrition.protein}</TableCell>
                    </TableRow>
                     <TableRow>
                      <TableCell>Fat (g)</TableCell>
                      <TableCell className="text-right">{dish.nutrition.original.fat}</TableCell>
                      <TableCell className="text-right">{plantBasedNutrition.fat}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Carbs (g)</TableCell>
                      <TableCell className="text-right">{dish.nutrition.original.carbohydrates}</TableCell>
                      <TableCell className="text-right">{plantBasedNutrition.carbohydrates}</TableCell>
                    </TableRow>
                  </>
                )}
              </TableBody>
            </Table>
          </div>
          {plantBasedNutrition && showOptimizedNutrition && (
             <NutritionLabelDialog dish={dish} plantBasedNutrition={plantBasedNutrition} />
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>💰 Price Comparison</CardTitle>
          <CardDescription>
            Estimated cost per serving for original vs. plant-based.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-sm text-muted-foreground">Original Dish</p>
              <p className="text-3xl font-bold">${dish.price.original.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Plant-Based</p>
              <p className="text-3xl font-bold text-primary">${dish.price.plantBased.toFixed(2)}</p>
            </div>
          </div>
          {(() => {
            const difference = dish.price.plantBased - dish.price.original;
            const percentageChange = (difference / dish.price.original) * 100;
            if (difference > 0) {
              return (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Cost Increase</AlertTitle>
                  <AlertDescription>
                    The plant-based version is estimated to be ${difference.toFixed(2)} ({percentageChange.toFixed(0)}%) more expensive per serving.
                  </AlertDescription>
                </Alert>
              )
            } else if (difference < 0) {
              return (
                <Alert>
                  <Sparkles className="h-4 w-4" />
                  <AlertTitle>Cost Savings</AlertTitle>
                  <AlertDescription>
                    The plant-based version is estimated to be ${Math.abs(difference).toFixed(2)} ({Math.abs(percentageChange).toFixed(0)}%) cheaper per serving.
                  </AlertDescription>
                </Alert>
              )
            } else {
                 return (
                    <Alert>
                        <Sparkles className="h-4 w-4" />
                        <AlertTitle>Cost Neutral</AlertTitle>
                        <AlertDescription>
                        The plant-based version has the same estimated cost.
                        </AlertDescription>
                    </Alert>
                )
            }
          })()}
        </CardContent>
      </Card>

      <Button asChild variant="outline" className="w-full">
        <a href="https://www.hyperpure.com/" target="_blank" rel="noopener noreferrer">
          For raw materials retailer you can click here
          <ExternalLink className="ml-2 h-4 w-4" />
        </a>
      </Button>
      
      <Card>
        <CardHeader>
           <CardTitle className="flex items-center gap-2"><Bot className="text-primary"/> 📢 AI Marketing Agent</CardTitle>
           <CardDescription>Generates marketing content and video reels based on daily food trends.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold">Detected Trends Today</h3>
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge variant="outline">🔥 High-protein plant-based meals</Badge>
              <Badge variant="outline">🌱 Dairy-free desserts</Badge>
              <Badge variant="outline">🏋️ Fitness-conscious eating</Badge>
            </div>
          </div>
          <div className="p-4 rounded-lg bg-muted/50">
             <h3 className="font-semibold">AI-Selected Strategy</h3>
             <div className="grid grid-cols-3 gap-4 mt-2 text-sm">
                <div><span className="font-medium text-muted-foreground">Platform</span><p>Instagram</p></div>
                <div><span className="font-medium text-muted-foreground">Format</span><p>Reel</p></div>
                <div><span className="font-medium text-muted-foreground">Core Message</span><p>Protein & taste parity</p></div>
             </div>
          </div>
          {marketingContent && (
             <div className="space-y-4">
                <div>
                   <label htmlFor="caption" className="text-sm font-medium">Ready-to-use Caption</label>
                   <Textarea id="caption" readOnly value={marketingContent.caption} className="mt-1 h-28" />
                </div>
                 <div>
                   <label htmlFor="hashtags" className="text-sm font-medium">Hashtags</label>
                   <Textarea id="hashtags" readOnly value={marketingContent.hashtags} className="mt-1" />
                </div>
             </div>
          )}
          {isGeneratingMarketing && (
            <div className="space-y-4">
              <Skeleton className="h-28 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          )}
           {videoReelUrl && (
            <div className="space-y-2">
              <h3 className="font-semibold">Generated Reel</h3>
              <video src={videoReelUrl} controls className="w-full rounded-lg" />
            </div>
          )}
          {isGeneratingReel && (
             <Alert>
              <Loader2 className="h-4 w-4 animate-spin" />
              <AlertTitle>Generating your video reel...</AlertTitle>
              <AlertDescription>
                This can take up to a minute. Please don't close this page.
              </AlertDescription>
            </Alert>
          )}
          <div className="flex flex-wrap gap-2">
            <Button onClick={handleGenerateMarketing} disabled={isGeneratingMarketing || isGeneratingReel}>
              {isGeneratingMarketing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Bot className="mr-2 h-4 w-4" />}
              {marketingContent ? "Regenerate Marketing Content" : "Run Today’s Marketing Agent"}
            </Button>
            {marketingContent && (
              <Button onClick={handleGenerateReel} disabled={isGeneratingReel || isGeneratingMarketing}>
                {isGeneratingReel ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                {videoReelUrl ? "Regenerate Reel" : "Generate Reel"}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

    </div>
  );
}
