import Link from "next/link";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MenuProvider } from "@/context/MenuContext";
import { Logo } from "@/components/app/logo";
import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <MenuProvider>
      <div className="min-h-screen bg-background text-foreground">
        <header className="flex h-20 items-center justify-between border-b bg-white px-8">
          <div className="flex items-center gap-4">
            <Link href="/dashboard" className="flex items-center gap-4">
              <div className="rounded-lg bg-primary p-2">
                <Logo className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="font-bold text-primary">VERDE</h1>
                <p className="text-xs text-muted-foreground">
                  Plant-Based Intelligence
                </p>
              </div>
            </Link>
          </div>
          <div className="flex h-full items-center">
            <Button
              variant="ghost"
              className="relative h-full rounded-none font-semibold text-primary after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-full after:bg-primary"
            >
              Menu Intelligence
            </Button>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarFallback className="bg-gray-200 font-semibold text-gray-600">SM</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-sm">Green Leaf Café</p>
                <p className="text-xs text-muted-foreground">Downtown Portland</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="text-muted-foreground" disabled>
              <Bell className="h-5 w-5" />
            </Button>
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Logout
            </Link>
          </div>
        </header>
        {children}
      </div>
    </MenuProvider>
  );
}
