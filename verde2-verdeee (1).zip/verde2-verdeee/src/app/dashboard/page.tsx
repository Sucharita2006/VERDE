"use client";

import Link from "next/link";
import { Utensils, ArrowRight } from "lucide-react";
import { useMenu } from "@/context/MenuContext";
import type { Dish } from "@/lib/data";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AddMenuItem } from "@/components/app/add-menu-item";

export default function MenuDashboardPage() {
  const { menuItems } = useMenu();
  
  const groupByCategory = (dishes: Dish[]) => {
    const grouped: Record<string, Dish[]> = {};
    for (const dish of dishes) {
      const category = dish.category;
      if (!grouped[category]) {
        grouped[category] = [];
      }
      grouped[category].push(dish);
    }
    return grouped;
  };

  const groupedMenu = groupByCategory(menuItems);
  const categories = Object.keys(groupedMenu);

  return (
    <main className="flex-1 p-4 md:p-8 lg:p-12">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Green Leaf Café Menu</h1>
          <p className="text-muted-foreground">Select a menu item to generate a plant-based alternative with validated nutrition</p>
        </div>
        <AddMenuItem />
      </div>


      <div className="space-y-12">
        {categories.map(category => (
          <section key={category}>
            <h2 className="mb-4 text-xl font-semibold flex items-center gap-2">
              <span className="text-primary">•</span> {category}
            </h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {groupedMenu[category].map(dish => (
                <Card key={dish.id} className="flex flex-col overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow duration-200 rounded-xl">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                        <div className="p-3 rounded-lg bg-gray-100">
                            <Utensils className="h-5 w-5 text-gray-500" />
                        </div>
                        <Badge variant="outline" className="font-normal border bg-gray-50">{dish.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="flex flex-col flex-grow justify-between gap-4 pt-2">
                    <div>
                        <h3 className="text-lg font-semibold">{dish.name}</h3>
                        <p className="mt-1 text-sm text-muted-foreground">{dish.description}</p>
                    </div>
                    <div className="border-t pt-4">
                        <div className="flex justify-between items-end">
                            <div>
                                <p className="text-xs text-muted-foreground">Starting at</p>
                                <p className="text-lg font-bold">${dish.price.original.toFixed(2)}</p>
                            </div>
                            <Link href={`/dashboard/dish/${dish.id}`} className="flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
                                Generate Alternative <ArrowRight className="h-4 w-4" />
                            </Link>
                        </div>
                        <div className="mt-4 text-sm space-y-2">
                          <div className="grid grid-cols-3 gap-x-2 text-center">
                              <div />
                              <div className="text-xs text-muted-foreground font-medium">Original</div>
                              <div className="text-xs text-primary font-medium">Plant-Based</div>
                          </div>
                          <div className="grid grid-cols-3 gap-x-2 text-center items-center">
                              <div className="text-muted-foreground text-left">Calories</div>
                              <div className="font-bold text-foreground">{dish.nutrition.original.calories}</div>
                              <div className="font-bold text-primary">{dish.nutrition.plantBasedOptimized.calories}</div>
                          </div>
                          <div className="grid grid-cols-3 gap-x-2 text-center items-center">
                              <div className="text-muted-foreground text-left">Protein</div>
                              <div className="font-bold text-foreground">{dish.nutrition.original.protein}g</div>
                              <div className="font-bold text-primary">{dish.nutrition.plantBasedOptimized.protein}g</div>
                          </div>
                          <div className="grid grid-cols-3 gap-x-2 text-center items-center">
                              <div className="text-muted-foreground text-left">Fat</div>
                              <div className="font-bold text-foreground">{dish.nutrition.original.fat}g</div>
                              <div className="font-bold text-primary">{dish.nutrition.plantBasedOptimized.fat}g</div>
                          </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        ))}
      </div>
    </main>
  );
}
