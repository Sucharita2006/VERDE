"use client"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Logo } from "@/components/app/logo"

const formSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email." }),
  password: z.string().min(1, {
    message: "Password is required.",
  }),
})

export default function LoginPage() {
  const router = useRouter()
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "sarah@greenleafcafe.com",
      password: "password",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values)
    router.push("/dashboard")
  }

  return (
    <main className="grid min-h-screen grid-cols-1 font-sans lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between bg-primary p-12 text-primary-foreground">
        <div className="flex items-center gap-4">
           <div className="rounded-lg border border-primary-foreground/30 p-2">
            <Logo className="h-6 w-6 text-primary-foreground" />
          </div>
          <span className="text-2xl font-bold tracking-wider">VERDE</span>
        </div>
        <div className="space-y-8">
          <h1 className="text-6xl font-serif font-bold leading-tight">
            Transform your menu.
            <br />
            Preserve the taste.
          </h1>
          <p className="max-w-md text-lg text-primary-foreground/80">
            AI-powered plant-based alternatives that match your signature dishes — with validated nutrition and market-ready marketing.
          </p>
          <div className="flex items-center gap-4">
             <div className="flex -space-x-4 overflow-hidden">
                <Image src="https://picsum.photos/seed/a/48/48" width={48} height={48} alt="Avatar 1" className="inline-block rounded-full ring-2 ring-primary-foreground"/>
                <Image src="https://picsum.photos/seed/b/48/48" width={48} height={48} alt="Avatar 2" className="inline-block rounded-full ring-2 ring-primary-foreground"/>
                <Image src="https://picsum.photos/seed/c/48/48" width={48} height={48} alt="Avatar 3" className="inline-block rounded-full ring-2 ring-primary-foreground"/>
                <Image src="https://picsum.photos/seed/d/48/48" width={48} height={48} alt="Avatar 4" className="inline-block rounded-full ring-2 ring-primary-foreground"/>
             </div>
            <span className="text-sm">200+ cafés already transforming their menus</span>
          </div>
        </div>
        <footer className="text-sm text-primary-foreground/60">
          © 2024 VERDE. Sustainable dining, powered by AI.
        </footer>
      </div>

      <div className="flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md space-y-8">
          <div>
            <h2 className="text-4xl font-serif font-bold">Welcome back</h2>
            <p className="text-muted-foreground mt-2">Sign in to access your café dashboard</p>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email address</FormLabel>
                    <FormControl>
                      <Input placeholder="sarah@greenleafcafe.com" {...field} className="bg-white"/>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex justify-between items-center">
                      <FormLabel>Password</FormLabel>
                      <Link href="#" className="text-sm text-primary hover:underline">
                        Forgot password?
                      </Link>
                    </div>
                    <FormControl>
                      <Input type="password" {...field} className="bg-white" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full text-base">
                Sign in to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </form>
          </Form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                DEMO CREDENTIALS PRE-FILLED
              </span>
            </div>
          </div>

           <p className="text-center text-sm text-muted-foreground">
              New to VERDE?{' '}
              <Link href="#" className="font-semibold text-primary hover:underline">
                Request a demo
              </Link>
            </p>
        </div>
      </div>
    </main>
  )
}
