# **App Name**: VERDE: Plant-Based Transition Platform

## Core Features:

- Café Login (Mocked): Simple login using Café Name and Location, focusing on ease of access and user-friendliness.
- Café Menu Dashboard (Preloaded): Display a preloaded menu with dish names, categories, and popularity indicators, with a CTA to analyze for plant-based transition.
- AI Plant-Based Reformulation: Analyzes dishes and suggests plant-based alternatives, providing metrics for taste and texture similarity. Provides a tool to determine if any adjustments should be made to the suggestion based on information available.
- Nutrition Validation: Side-by-side nutrition comparison of original and plant-based dishes, automatically adjusting the formulation to match the original nutrition and generating printable nutrition labels.
- Impact Indicator: Displays an estimated number of animal lives spared per year by switching to the plant-based dish.
- AI Marketing Agent: Leverages generative AI to scans daily food trends and consumer interest, generating marketing content (captions and hashtags) tailored for platforms like Instagram, to effectively market the new plant-based dish.

## Style Guidelines:

- Primary color: Earthy green (#8FBC8F) to evoke nature and health. This choice is based on the request for the app to be earthy and the nature of it focusing on plant-based products.
- Background color: Off-white (#F8F8FF) for a clean and unobtrusive backdrop, creating a neutral canvas for the interface. It is visibly the same hue as the primary color, but heavily desaturated and with a brightness appropriate to the chosen light scheme.
- Accent color: Muted olive (#A8B878) to complement the primary color, and bring contrast to the UI. It is analogous to the primary, yet differs significantly in both brightness and saturation, creating good contrast and attracting user attention to CTAs or areas of the screen that are of interest.
- Body and headline font: 'PT Sans', a humanist sans-serif offering a blend of modern aesthetics with slight warmth, suitable for both headers and content.
- Utilize a card-based layout to clearly organize information, ensuring a structured and digestible presentation for the user.
- Employ minimalist icons that visually represent dish categories, nutritional information, and marketing strategies, enhancing user understanding and engagement.
- Incorporate subtle animations such as smooth transitions and loading states to improve the user experience, making the app feel polished and responsive without being distracting.